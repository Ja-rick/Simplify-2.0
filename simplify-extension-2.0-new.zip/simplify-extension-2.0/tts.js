// tts.js
// Purpose: Handles Text-to-Speech via OpenAI's /v1/audio/speech endpoint

// You can set this up as a module and call it from popup.js or elsewhere
export async function playTTS(text, voice = "shimmer") {
  const apiKey = "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";

  // OpenAI TTS has two models: "tts-1" (fast) and "tts-1-hd" (better quality)
  const model = "tts-1"; 

  // Safety: ignore if empty or not a string
  if (!text || typeof text !== "string") return;

  try {
    const response = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: model,
        voice: voice,       // Options: "onyx", "nova", "shimmer", "echo", "fable", "alloy"
        input: text
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI TTS error: ${response.status} ${response.statusText}`);
    }

    // TTS returns a binary stream of audio (in mp3 format)
    const audioBlob = await response.blob();

    // Create a temporary audio element to play the sound
    const audioUrl = URL.createObjectURL(audioBlob);
    const audio = new Audio(audioUrl);

    // Optional: set this to false if you want it silent until user hits "play"
    audio.autoplay = true;

    audio.onended = () => {
      // Clean up the blob URL after playback
      URL.revokeObjectURL(audioUrl);
    };

    audio.onerror = (err) => {
      console.error("Audio playback error:", err);
    };

  } catch (err) {
    console.error("TTS failed:", err);
  }
}
