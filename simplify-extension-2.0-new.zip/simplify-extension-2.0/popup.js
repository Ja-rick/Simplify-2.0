// popup.js
import { playTTS } from "./tts.js";

const API_KEY = "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";


const simplifyBtn = document.getElementById('simplify');
const copyBtn = document.getElementById('copyButton');
const outputEl = document.getElementById('output');
const ttsToggle = document.getElementById('ttsToggle');

simplifyBtn.addEventListener('click', async () => {
  const input = document.getElementById('text').value;
  const level = document.getElementById('level').value;
  const length = document.getElementById('length').value;

  outputEl.innerText = "⏳ Simplifying...";
  copyBtn.style.display = 'none';
  copyBtn.classList.remove('copied');
  copyBtn.innerText = "📋 Copy to Clipboard";

  // Build dynamic prompt
  let levelInstruction = '';
  if (level === '5') levelInstruction = 'Explain this like the user is 5 years old.';
  else if (level === 'highschool') levelInstruction = 'Explain this as if the user is in high school.';
  else levelInstruction = 'Explain this at a graduate-level depth and vocabulary.';

  let lengthInstruction = '';
  if (length === 'brief') lengthInstruction = 'Keep the response very short, 1–2 sentences.';
  else if (length === 'extended') lengthInstruction = 'Give a medium-length explanation, 1–2 paragraphs.';
  else lengthInstruction = 'Give a deep dive explanation, up to 4 paragraphs maximum.';

  const systemPrompt = `${levelInstruction} ${lengthInstruction}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: input }
        ]
      })
    });

    const data = await response.json();
    console.log("🧪 OpenAI Raw Response:", data);

    if (data.error) {
      outputEl.innerText = `❌ OpenAI Error: ${data.error.message}`;
      return;
    }

    if (data.choices && data.choices.length > 0) {
      const result = data.choices[0].message.content.trim();
      outputEl.innerText = result;
      copyBtn.style.display = 'block';

      const ttsEnabled = await chrome.storage.local.get("ttsEnabled");
      if (ttsEnabled.ttsEnabled) {
        playTTS(result);
      }
    } else {
      outputEl.innerText = "⚠️ No response from OpenAI. Check console for details.";
      console.warn("⚠️ Unexpected OpenAI response format:", data);
    }
  } catch (err) {
    outputEl.innerText = "❌ Fetch Error: " + err.message;
    console.error("🔥 OpenAI fetch failed:", err);
  }
});

copyBtn.addEventListener('click', () => {
  const text = outputEl.innerText;
  navigator.clipboard.writeText(text).then(() => {
    copyBtn.innerText = "✅ Copied!";
    copyBtn.classList.add('copied');
  });
});

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get("ttsEnabled", (data) => {
    ttsToggle.checked = data.ttsEnabled || false;
  });

  ttsToggle.addEventListener("change", () => {
    const isProUser = true; // Replace with real check if needed
    if (!isProUser) {
      alert("🔒 TTS is a Pro feature. Upgrade to unlock voice magic!");
      ttsToggle.checked = false;
      chrome.storage.local.set({ ttsEnabled: false });
      return;
    }

    chrome.storage.local.set({ ttsEnabled: ttsToggle.checked });
    if (ttsToggle.checked) {
      playTTS("Text-to-speech enabled. Ready to simplify and speak.");
    }
  });
});
