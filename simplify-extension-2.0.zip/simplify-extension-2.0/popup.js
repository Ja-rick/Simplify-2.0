// popup.js
import { playTTS } from "./tts.js";

const API_KEY = atob("c2stcHJvai1qQkEtdllYRG5ZRjFGSWZkalVwekpLcVBXaGNYZEhsUVBDTXczY0pnVU5rMUU5LXd3a0ZiV1k2c2lIem1FV2dDTHlqUWNuV1FpMVQzQmxia0ZKOU01V2gxZEUwdE94M18wejBOeW1ydkhqZVNpdG5MbEdMN0k2b3hpMm4yODU4d0ZwV1RfdFNyVWRJY2xBY0s1ck01b2VZdjhHWUE=");

const simplifyBtn = document.getElementById('simplify');
const copyBtn = document.getElementById('copyButton');
const outputEl = document.getElementById('output');
const ttsToggle = document.getElementById('ttsToggle');

simplifyBtn.addEventListener('click', async () => {
  const input = document.getElementById('text').value;
  outputEl.innerText = "⏳ Simplifying...";
  copyBtn.style.display = 'none';
  copyBtn.classList.remove('copied');
  copyBtn.innerText = "📋 Copy to Clipboard";

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'Simplify this like the user is 5 years old.' },
          { role: 'user', content: input }
        ]
      })
    });

    const data = await response.json();

    if (data.choices && data.choices.length > 0) {
      const result = data.choices[0].message.content.trim();
      outputEl.innerText = result;
      copyBtn.style.display = 'block';

      const ttsEnabled = await chrome.storage.local.get("ttsEnabled");
      if (ttsEnabled.ttsEnabled) {
        playTTS(result);
      }
    } else {
      outputEl.innerText = "⚠️ No response from OpenAI.";
    }
  } catch (err) {
    outputEl.innerText = "❌ Error: " + err.message;
  }
});

copyBtn.addEventListener('click', () => {
  const text = outputEl.innerText;
  navigator.clipboard.writeText(text).then(() => {
    copyBtn.innerText = "✅ Copied!";
    copyBtn.classList.add('copied');
  });
});

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get("ttsEnabled", (data) => {
    ttsToggle.checked = data.ttsEnabled || false;
  });

  ttsToggle.addEventListener("change", () => {
    // Tease: Let free users SEE the toggle but block use
    const isProUser = true; // Replace with real check
    if (!isProUser) {
      alert("🔒 TTS is a Pro feature. Upgrade to unlock voice magic!");
      ttsToggle.checked = false;
      chrome.storage.local.set({ ttsEnabled: false });
      return;
    }

    chrome.storage.local.set({ ttsEnabled: ttsToggle.checked });
    if (ttsToggle.checked) {
      playTTS("Text-to-speech enabled. Ready to simplify and speak.");
    }
  });
});
