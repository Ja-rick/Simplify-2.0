// popup.js
import { playTTS } from "./tts.js";

const API_KEY     = "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";
const simplifyBtn = document.getElementById("simplify");
const copyBtn     = document.getElementById("copyButton");
const speakBtn    = document.getElementById("ttsSpeak");
const outputEl    = document.getElementById("output");
const loader      = document.getElementById("loader");

simplifyBtn.addEventListener("click", async () => {
  const text   = document.getElementById("text").value.trim();
  const level  = document.getElementById("level").value;
  const length = document.getElementById("length").value;
  const format = document.getElementById("formatting").value;

  // ① Show loader, hide previous output & copy button
  outputEl.style.display = "none";
  loader.style.display   = "flex";
  copyBtn.style.display  = "none";
  copyBtn.classList.remove("copied");

  // Build instructions
  let lvlInst = level === "5"
    ? "Explain like I’m 5 years old."
    : level === "highschool"
      ? "Explain as if the user is in high school."
      : "Explain at a graduate-level depth and vocabulary.";

  let lenInst = length === "brief"
    ? "Keep it very short, 1–2 sentences."
    : length === "extended"
      ? "Make it medium length, 1–2 paragraphs."
      : "Give a deep dive, up to 4 paragraphs.";

  let fmtInst = "";
  if (format === "notes") {
    fmtInst = [
      "Structure your answer in three sections with headers:",
      "1) Overview: 2–3 very concise bullet points.",
      "2) Details: brief sentences highlighting key ideas.",
      "3) Notes: extra context or examples in short bullet form."
    ].join(" ");
  }
  else if (format === "keypoints") {
    fmtInst = "Give me only the key points as a simple bullet list, no extra prose.";
  }
  // default => fmtInst stays empty

  const prompt = `${lvlInst} ${lenInst} ${fmtInst}\n\n${text}`;

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful text simplifier." },
          { role: "user", content: prompt }
        ]
      })
    });
    const data = await res.json();
    const simplified = data.choices?.[0]?.message?.content?.trim()
      || "⚠️ No response.";

    // ② Hide loader, show output
    loader.style.display   = "none";
    outputEl.style.display = "block";
    outputEl.innerText     = simplified;

    // Reveal copy button
    copyBtn.style.display = "block";
  }
  catch (err) {
    loader.style.display   = "none";
    outputEl.style.display = "block";
    outputEl.innerText     = "❌ Error: " + err.message;
  }
});

copyBtn.addEventListener("click", () => {
  const txt = outputEl.innerText;
  navigator.clipboard.writeText(txt).then(() => {
    copyBtn.innerText = "✅ Copied!";
    copyBtn.classList.add("copied");
    setTimeout(() => {
      copyBtn.innerText = " Copy to Clipboard";
      copyBtn.classList.remove("copied");
    }, 1500);
  });
});

speakBtn.addEventListener("click", () => {
  const text  = outputEl.innerText.trim();
  const voice = document.getElementById("voice").value;
  if (text) playTTS(text, voice);
});
