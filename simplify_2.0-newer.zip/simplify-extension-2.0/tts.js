// tts.js
export async function playTTS(text, voice = "shimmer") {
  const API_KEY = "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";

  try {
    const res = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "tts-1",
        voice,
        input: text
      })
    });

    if (!res.ok) throw new Error(`TTS failed: ${res.statusText}`);

    const blob = await res.blob();
    const url  = URL.createObjectURL(blob);
    const audio = new Audio(url);
    audio.autoplay = true;
    audio.onended = () => URL.revokeObjectURL(url);

  } catch (err) {
    console.error("🔊 TTS error:", err);
  }
}
