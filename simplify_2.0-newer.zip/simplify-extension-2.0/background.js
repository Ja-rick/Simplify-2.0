chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "simplifyText",
    title: "Simplify this text",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "simplifyText") {
    const selectedText = info.selectionText;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer 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',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'Simplify this like the user is 5 years old.' },
          { role: 'user', content: selectedText }
        ]
      })
    });

    const data = await response.json();
    const simplified = data?.choices?.[0]?.message?.content || "⚠️ No response";

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (result) => alert("Simplified: " + result),
      args: [simplified]
    });
  }
});
